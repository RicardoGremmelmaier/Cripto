#ifndef aleatorio_h
#define aleatorio_h

int aleatorio (void) {};
  
void semente (unsigned seed) {};

#endif